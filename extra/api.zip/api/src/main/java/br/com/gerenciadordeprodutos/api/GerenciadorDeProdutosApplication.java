package br.com.gerenciadordeprodutos.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciadorDeProdutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciadorDeProdutosApplication.class, args);
	}

}
